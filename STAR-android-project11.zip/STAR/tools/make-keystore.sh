#!/usr/bin/env bash
# Creates YOUR private STAR signing key and prints the four values GitHub needs as "secrets".
# Every update of STAR must be signed with this same key, or Android refuses to install it over the old one.
set -euo pipefail

if ! command -v keytool >/dev/null 2>&1; then
  echo "keytool not found. Install a JDK first (Android Studio already includes one)."
  exit 1
fi

read -r -s -p "Choose a password for the key (8+ characters, remember it): " PW
echo
ALIAS="star"

keytool -genkeypair -keystore star-release.jks -alias "$ALIAS" \
  -keyalg RSA -keysize 4096 -validity 36500 \
  -storepass "$PW" -keypass "$PW" -dname "CN=STAR personal build"

echo
echo "Created star-release.jks. Now open your GitHub repository:"
echo "  Settings -> Secrets and variables -> Actions -> New repository secret"
echo "and add these four secrets:"
echo
echo "  STAR_KEYSTORE_PASSWORD = the password you just typed"
echo "  STAR_KEY_ALIAS         = $ALIAS"
echo "  STAR_KEY_PASSWORD      = the same password"
echo "  STAR_KEYSTORE_BASE64   = the long text printed between the lines below"
echo "-----BEGIN-----"
if base64 -w0 star-release.jks 2>/dev/null; then :; else base64 star-release.jks | tr -d '\n'; fi
echo
echo "-----END-----"
echo
echo "Keep star-release.jks somewhere safe and NEVER share or upload it."
echo "If you lose it you can't publish updates that install over your current STAR."
