# STAR - your personal AI for Android

STAR is a private AI assistant app for your Android phone.

- **Opens only with a strong biometric** (fingerprint or face/iris, whichever your phone rates "strong"). There is no PIN, pattern or password fallback.
- **Everything it stores is encrypted** (your API key, settings and chats) with a key that your phone's secure hardware releases only right after a scan.
- **Uses Claude** (Anthropic's AI) as its brain, with live web search so current facts come from sources, with links.
- **Can update itself** from your own GitHub page, and you can change how it behaves any time (Settings -> "Your instructions to STAR").

## What STAR honestly is not

- **Not unhackable.** Nothing is. STAR is built to be hard to break (see "How it protects you"), but if someone controls your unlocked phone, or you install a fake copy of STAR, no app can protect you.
- **Not unlimited or all-knowing.** It runs on Claude, which is very capable but can still be wrong and has a knowledge cutoff (web search covers recent things). Claude keeps its own safety rules, so STAR will decline harmful requests.
- **Not "fingerprint AND face".** Android doesn't let an app demand two different biometrics together. STAR requires a strong biometric every single time and accepts whichever strong one your phone has.
- **Face/eye unlock may not qualify.** Only biometrics that Android rates "strong" (Class 3) can protect STAR's key. On most phones that is the fingerprint sensor only; ordinary face unlock is rated "weak" and will not be accepted, and iris scanners are rare. If your phone has no strong biometric, STAR tells you and will not run.
- **Needs internet and an Anthropic API key** (you pay Anthropic for what you use; see "Cost").

---

## Put STAR on your phone (one time, about 20-30 minutes)

You need: a free **GitHub** account, an **Anthropic API key**, and one computer with Java for step 2 (only once; Android Studio includes Java).

### 1. Put the code on GitHub
1. On github.com create a new repository called `star` and make it **Public**. (Public is needed so the app can look for updates without a password. The code contains no keys or personal data.)
2. Upload everything in this folder. Make sure the hidden `.github` folder goes up too. If it doesn't, click *Add file -> Create new file*, type `.github/workflows/build.yml` as the name and paste in the contents of that file.

### 2. Make your private signing key (this is what makes updates possible)
Android only accepts an update if it is signed with the same key as the installed app.
1. On your computer, in this folder, run: `bash tools/make-keystore.sh`
2. It prints four values. In your GitHub repository go to *Settings -> Secrets and variables -> Actions -> New repository secret* and add all four: `STAR_KEYSTORE_BASE64`, `STAR_KEYSTORE_PASSWORD`, `STAR_KEY_ALIAS`, `STAR_KEY_PASSWORD`.
3. Keep the file `star-release.jks` somewhere safe and never share it. If you lose it, you can't publish updates that install over your current STAR.

### 3. Build the app
In your repository: *Releases -> Create a new release*, type the tag `v1.0.0`, press *Publish release*. Open the *Actions* tab to watch the build (about 5 minutes). When it finishes, the release contains `STAR-1.0.0.apk` and a `.sha256` file.

### 4. Install it
On your phone open the release page, download `STAR-1.0.0.apk`, open it, and allow "install unknown apps" for your browser when Android asks.

### 5. First run
1. Open STAR -> **Set up with biometrics** -> scan. (Your phone needs at least one fingerprint or face enrolled.)
2. In Settings paste your **Anthropic API key**, pick a model, then **Save**.
3. For updates, type `your-github-name/star` under *Updates* and Save.

---

## Phone-only build (no computer, no signing key)

If you only have a phone, let GitHub build the APK from this zip:
1. Create a **public** repository (github.com/new).
2. In it tap *Add file -> Create new file*, name it `.github/workflows/build.yml`, paste in the contents of `tools/phone-build.yml` from this zip, and commit.
3. Tap *Add file -> Upload files*, upload `STAR-android-project.zip` (the whole zip, don't unzip it) and commit. The build starts by itself (about 5-10 minutes). You can follow it in the *Actions* tab.
4. When it finishes, open *Releases* on the repository's main page and download `STAR.apk`, then install it.

This build uses a throwaway signing key, so STAR works but cannot update itself in place. For that, use the signing-key steps above.

## Updating STAR and adding features

- **Change how STAR behaves:** Settings -> *Your instructions to STAR*. Takes effect immediately. Example: "Call me Sam. Keep answers short. Explain exam topics step by step."
- **Add new features:** ask Claude to change the code, upload the changes to GitHub, then create a release with the next number (`v1.0.1`, `v1.0.2`...).
- **Getting the update:** STAR checks once a day and sends a notification. Open STAR -> Settings -> Updates. It downloads the file, checks the checksum, checks that it is STAR and is signed with your key, and then Android asks you to confirm with one tap. Android doesn't allow sideloaded apps to install themselves with no confirmation at all.
- **New Claude models:** Settings -> *Refresh model list* adds newer models without any app update.

## How it protects you

- The key that protects your data lives in the phone's secure hardware (the separate security chip when the phone has one). It can be used only immediately after a fresh strong-biometric scan, every time.
- Adding a new fingerprint or face to the phone destroys that key. STAR then resets itself instead of letting someone who knows your phone PIN add their own finger.
- STAR locks the moment you leave it or the screen turns off (you can allow a short grace period in Settings), and an answer still arriving is stopped when it locks.
- Screenshots and the app-switcher preview are blocked (can be turned off).
- Cloud backup and phone-to-phone transfer are switched off for STAR's data.
- Connections are encrypted only. Plain http is blocked.
- Updates are accepted only if the checksum matches, the package is STAR, it is newer, and it is signed with the same key as the installed app.
- STAR has no third-party libraries inside it: only Android itself and Kotlin's standard library.

**Your questions are sent to Anthropic** so Claude can answer them. Don't type anything you wouldn't be comfortable sending to them.

## Cost

You pay Anthropic directly, per use. When this was written: Claude Opus 5.5 was $4 / $20 per million input / output tokens, Sonnet 5.5 $2 / $10, and web search $10 per 1,000 searches. Check current prices at https://platform.claude.com/docs/en/about-claude/pricing. Sonnet 5.5 is about half the cost of Opus 5.5; set it in Settings if you want to spend less.

## Building without GitHub

Open this folder in Android Studio and choose *Build -> Build APK(s)*, or run `./gradlew assembleRelease`. Without the signing secrets the APK is signed with a throwaway debug key, which is fine for trying it out but cannot be updated in place by a differently-signed build.

## Files

- `Vault.kt` / `Biometrics.kt` - the hardware key, the biometric lock and encryption
- `ClaudeClient.kt` - talks to Claude (streaming, web search, model list)
- `Updater.kt` - checks GitHub releases, verifies and installs updates
- `MainActivity.kt`, `ChatScreen.kt`, `SettingsScreen.kt`, `Screens.kt`, `Ui.kt`, `Markdown.kt` - the screens
- `.github/workflows/build.yml` - builds and publishes the APK in the cloud
