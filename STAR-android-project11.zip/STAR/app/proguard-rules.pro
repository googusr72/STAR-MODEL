# STAR uses no reflection and no third-party libraries, so the defaults are enough.
