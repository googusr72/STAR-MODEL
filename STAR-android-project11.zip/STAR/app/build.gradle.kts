plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// The release workflow passes these in; local builds use the defaults.
val starVersionName: String = (project.findProperty("starVersionName") as String?) ?: "1.0.0"
val starVersionCode: Int = (project.findProperty("starVersionCode") as String?)?.toIntOrNull() ?: 1

android {
    namespace = "app.star.assistant"
    compileSdk = 35

    defaultConfig {
        applicationId = "app.star.assistant"
        minSdk = 30            // Android 11+: needed for strong-biometric-bound keys without extra libraries
        targetSdk = 35
        versionCode = starVersionCode
        versionName = starVersionName
    }

    signingConfigs {
        // Only used when the release workflow provides your private signing key.
        create("star") {
            val path = System.getenv("STAR_KEYSTORE_PATH")
            if (path != null) {
                storeFile = file(path)
                storePassword = System.getenv("STAR_KEYSTORE_PASSWORD")
                keyAlias = System.getenv("STAR_KEY_ALIAS")
                keyPassword = System.getenv("STAR_KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true      // shrinks + obfuscates the code
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = if (System.getenv("STAR_KEYSTORE_PATH") != null) {
                signingConfigs.getByName("star")
            } else {
                signingConfigs.getByName("debug")
            }
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
}

// No dependencies: STAR only uses what Android itself provides.
