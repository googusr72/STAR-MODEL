package app.star.assistant

import android.graphics.Color
import android.graphics.Typeface
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.text.style.StyleSpan
import android.text.style.TypefaceSpan
import android.text.style.URLSpan

/**
 * A small Markdown renderer: headings, **bold**, `code`, ``` code blocks ```, bullet lists, quotes and [links](https://...).
 * Anything it doesn't understand is shown as plain text, so nothing is ever lost.
 */
object Markdown {
    private const val FLAGS = Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
    private val codeBg = Color.parseColor("#1B2342")
    private val codeFg = Color.parseColor("#C9D6FF")
    private val quoteFg = Color.parseColor("#AEB7DD")
    private val headingSizes = floatArrayOf(1.0f, 1.3f, 1.2f, 1.1f, 1.05f)
    private val headingRe = Regex("^(#{1,4})\\s+(.*)$")
    private val bulletRe = Regex("^[-*+]\\s+.*")
    private val ruleRe = Regex("^(-{3,}|\\*{3,}|_{3,})$")
    private val tableSepRe = Regex("^\\|?[\\s:|-]+\\|[\\s:|-]*$")

    fun render(src: String): CharSequence {
        val out = SpannableStringBuilder()
        val lines = src.split("\n")
        var inCode = false
        var codeStart = 0

        for (idx in lines.indices) {
            val line = lines[idx].trimEnd('\r')

            if (line.trimStart().startsWith("```")) {
                if (!inCode) {
                    inCode = true
                    codeStart = out.length
                } else {
                    inCode = false
                    styleCode(out, codeStart, out.length - 1)
                }
                continue
            }
            if (inCode) {
                out.append(line).append('\n')
                continue
            }

            val trimmed = line.trimStart()
            val indent = (line.length - trimmed.length) / 2

            val heading = headingRe.find(trimmed)
            if (heading != null) {
                val level = heading.groupValues[1].length
                val start = out.length
                inline(out, heading.groupValues[2])
                out.setSpan(StyleSpan(Typeface.BOLD), start, out.length, FLAGS)
                out.setSpan(RelativeSizeSpan(headingSizes[level]), start, out.length, FLAGS)
            } else if (bulletRe.matches(trimmed)) {
                out.append("    ".repeat(indent)).append("• ")
                inline(out, trimmed.substring(1).trimStart())
            } else if (trimmed.startsWith(">")) {
                val start = out.length
                out.append("▌ ")
                inline(out, trimmed.substring(1).trimStart())
                out.setSpan(ForegroundColorSpan(quoteFg), start, out.length, FLAGS)
            } else if (ruleRe.matches(trimmed)) {
                out.append("────────")
            } else if (tableSepRe.matches(trimmed) && trimmed.contains("-")) {
                // table separator row: skip it (and its newline)
                continue
            } else {
                out.append("    ".repeat(indent))
                inline(out, trimmed)
            }
            if (idx < lines.size - 1) out.append('\n')
        }
        if (inCode) styleCode(out, codeStart, out.length)
        return out
    }

    private fun styleCode(out: SpannableStringBuilder, start: Int, end: Int) {
        if (end <= start) return
        out.setSpan(TypefaceSpan("monospace"), start, end, FLAGS)
        out.setSpan(BackgroundColorSpan(codeBg), start, end, FLAGS)
        out.setSpan(ForegroundColorSpan(codeFg), start, end, FLAGS)
        out.setSpan(RelativeSizeSpan(0.88f), start, end, FLAGS)
    }

    private fun inline(out: SpannableStringBuilder, s: String) {
        var i = 0
        val n = s.length
        while (i < n) {
            val c = s[i]

            if (c == '*' && s.startsWith("**", i)) {
                val end = s.indexOf("**", i + 2)
                if (end > i + 2) {
                    val start = out.length
                    inline(out, s.substring(i + 2, end))
                    out.setSpan(StyleSpan(Typeface.BOLD), start, out.length, FLAGS)
                    i = end + 2
                    continue
                }
            }

            if (c == '`') {
                val end = s.indexOf('`', i + 1)
                if (end > i + 1) {
                    val start = out.length
                    out.append(s.substring(i + 1, end))
                    out.setSpan(TypefaceSpan("monospace"), start, out.length, FLAGS)
                    out.setSpan(BackgroundColorSpan(codeBg), start, out.length, FLAGS)
                    out.setSpan(ForegroundColorSpan(codeFg), start, out.length, FLAGS)
                    i = end + 1
                    continue
                }
            }

            if (c == '[') {
                val mid = s.indexOf("](", i + 1)
                if (mid > i) {
                    val close = s.indexOf(')', mid + 2)
                    if (close > mid) {
                        val label = s.substring(i + 1, mid)
                        val url = s.substring(mid + 2, close).trim()
                        if (url.startsWith("https://") || url.startsWith("http://")) {
                            val start = out.length
                            out.append(label)
                            out.setSpan(URLSpan(url), start, out.length, FLAGS)
                            i = close + 1
                            continue
                        }
                    }
                }
            }

            out.append(c)
            i++
        }
    }
}
