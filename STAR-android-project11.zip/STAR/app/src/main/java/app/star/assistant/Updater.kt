package app.star.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.content.pm.PackageManager
import android.content.pm.PackageInfo
import android.net.Uri
import android.os.Build
import android.provider.Settings
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

class UpdateInfo(
    val version: String,
    val notes: String,
    val apkUrl: String,
    val sha256: String?
)

/**
 * Self-update from the GitHub "Releases" page of a repository you choose in Settings.
 *
 * Safety checks before anything is installed:
 *  1. Download only over HTTPS.
 *  2. The file must match the SHA-256 checksum published with the release.
 *  3. It must be the STAR package, newer than the installed one, and signed with the SAME key as the
 *     installed STAR. (Android enforces #3 again on its own when installing.)
 */
object Updater {
    private const val CHANNEL = "star_updates"
    private const val NOTIFY_UPDATE = 41
    private const val NOTIFY_RESULT = 42
    private val repoPattern = Regex("^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$")

    @Suppress("DEPRECATION")
    fun installedVersion(context: Context): String =
        context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "0"

    /** Returns the newer release, or null when STAR is already up to date. Call from a background thread. */
    fun check(context: Context): UpdateInfo? {
        val repo = PublicPrefs.updateRepo(context)
        if (!repoPattern.matches(repo)) throw IOException("Enter the update source as owner/repository first.")

        val json = getText("https://api.github.com/repos/$repo/releases/latest", "No release found in $repo yet.")
        val release = JSONObject(json)
        val tag = release.optString("tag_name", "")
        if (tag.isEmpty() || !isNewer(tag, installedVersion(context))) return null

        val assets = release.optJSONArray("assets") ?: return null
        var apkName = ""
        var apkUrl = ""
        val checksums = HashMap<String, String>() // asset name -> download url
        for (i in 0 until assets.length()) {
            val a = assets.optJSONObject(i) ?: continue
            val name = a.optString("name", "")
            val url = a.optString("browser_download_url", "")
            if (name.endsWith(".apk") && apkUrl.isEmpty()) {
                apkName = name
                apkUrl = url
            }
            if (name.endsWith(".sha256")) checksums[name] = url
        }
        if (apkUrl.isEmpty()) throw IOException("The release has no APK file attached.")

        var sha: String? = null
        val shaUrl = checksums[apkName + ".sha256"]
        if (shaUrl != null) {
            val m = Regex("[0-9a-fA-F]{64}").find(getText(shaUrl, "Checksum file missing."))
            if (m != null) sha = m.value.lowercase()
        }
        return UpdateInfo(tag.removePrefix("v"), release.optString("body", ""), apkUrl, sha)
    }

    private fun getText(url: String, notFound: String): String {
        if (!url.startsWith("https://")) throw IOException("Refusing an insecure link.")
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15_000
        c.readTimeout = 25_000
        c.setRequestProperty("Accept", "application/vnd.github+json")
        c.setRequestProperty("User-Agent", "STAR-updater")
        try {
            val code = c.responseCode
            if (code == 404) throw IOException(notFound)
            if (code !in 200..299) throw IOException("GitHub answered HTTP $code.")
            return c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    fun isNewer(remote: String, local: String): Boolean {
        val r = numbers(remote)
        val l = numbers(local)
        for (i in 0 until maxOf(r.size, l.size)) {
            val a = r.getOrElse(i) { 0 }
            val b = l.getOrElse(i) { 0 }
            if (a != b) return a > b
        }
        return false
    }

    private fun numbers(v: String): List<Int> =
        v.trim().removePrefix("v").removePrefix("V").split('.', '-', '+').mapNotNull { it.toIntOrNull() }

    // ------------------------------------------------------------------ download + verify

    /** Downloads the APK, checks it, and returns the file. Call from a background thread. */
    fun download(context: Context, info: UpdateInfo, progress: (Int) -> Unit): File {
        if (info.sha256 == null) throw IOException("This release has no .sha256 checksum file, so STAR won't install it.")
        if (!info.apkUrl.startsWith("https://")) throw IOException("Refusing an insecure download link.")

        val dir = File(context.cacheDir, "updates")
        dir.mkdirs()
        dir.listFiles()?.forEach { it.delete() }
        val file = File(dir, "STAR-update.apk")

        val digest = MessageDigest.getInstance("SHA-256")
        val c = URL(info.apkUrl).openConnection() as HttpURLConnection
        c.connectTimeout = 20_000
        c.readTimeout = 60_000
        c.setRequestProperty("User-Agent", "STAR-updater")
        try {
            val code = c.responseCode
            if (code !in 200..299) throw IOException("Download failed (HTTP $code).")
            val total = c.contentLengthLong
            c.inputStream.use { input ->
                FileOutputStream(file).use { out ->
                    val buf = ByteArray(64 * 1024)
                    var done = 0L
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        digest.update(buf, 0, n)
                        done += n
                        if (total > 0) progress((done * 100 / total).toInt())
                    }
                }
            }
        } finally {
            c.disconnect()
        }

        val actual = hex(digest.digest())
        if (!actual.equals(info.sha256, ignoreCase = true)) {
            file.delete()
            throw IOException("The download doesn't match its published checksum, so it was thrown away.")
        }
        verifyApk(context, file)
        return file
    }

    private fun hex(bytes: ByteArray): String {
        val sb = StringBuilder()
        for (b in bytes) sb.append(String.format("%02x", b))
        return sb.toString()
    }

    @Suppress("DEPRECATION")
    private fun verifyApk(context: Context, file: File) {
        val pm = context.packageManager
        val archive = pm.getPackageArchiveInfo(file.absolutePath, PackageManager.GET_SIGNING_CERTIFICATES)
            ?: throw IOException("The downloaded file isn't a valid app.")
        if (archive.packageName != context.packageName) throw IOException("The downloaded app is not STAR.")
        val mine = pm.getPackageInfo(context.packageName, PackageManager.GET_SIGNING_CERTIFICATES)
        if (archive.longVersionCode <= mine.longVersionCode) {
            file.delete()
            throw IOException("The downloaded version isn't newer than the one you have.")
        }
        val a = signers(archive)
        val b = signers(mine)
        if (a.isEmpty() || a != b) {
            file.delete()
            throw IOException(
                "This update is signed with a different key than your installed STAR, so Android would refuse it. " +
                    "Nothing was installed."
            )
        }
    }

    private fun signers(p: PackageInfo): Set<String> {
        val info = p.signingInfo ?: return emptySet()
        val out = HashSet<String>()
        for (s in info.apkContentsSigners) {
            out.add(hex(MessageDigest.getInstance("SHA-256").digest(s.toByteArray())))
        }
        return out
    }

    // ------------------------------------------------------------------ install

    fun canInstall(context: Context): Boolean = context.packageManager.canRequestPackageInstalls()

    fun allowInstallIntent(context: Context): Intent =
        Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + context.packageName))

    /** Hands the verified APK to Android's installer. Android shows its own confirmation. */
    fun install(context: Context, apk: File) {
        val installer = context.packageManager.packageInstaller
        val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL)
        params.setAppPackageName(context.packageName)
        if (Build.VERSION.SDK_INT >= 31) {
            params.setRequireUserAction(PackageInstaller.SessionParams.USER_ACTION_NOT_REQUIRED)
        }
        val id = installer.createSession(params)
        installer.openSession(id).use { session ->
            FileInputStream(apk).use { input ->
                session.openWrite("star.apk", 0, apk.length()).use { out ->
                    input.copyTo(out)
                    session.fsync(out)
                }
            }
            val intent = Intent(context, InstallResultReceiver::class.java)
            val pending = PendingIntent.getBroadcast(
                context, id, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
            )!!
            session.commit(pending.intentSender)
        }
    }

    // ------------------------------------------------------------------ notifications

    fun notifyUpdate(context: Context, version: String) =
        post(context, NOTIFY_UPDATE, "STAR $version is ready", "Open STAR, then Settings, then Updates to install it.")

    fun notifyResult(context: Context, title: String, text: String) = post(context, NOTIFY_RESULT, title, text)

    private fun post(context: Context, id: Int, title: String, text: String) {
        val nm = context.getSystemService(NotificationManager::class.java) ?: return
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "STAR updates", NotificationManager.IMPORTANCE_DEFAULT)
        )
        val open = PendingIntent.getActivity(
            context, 0,
            Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(context, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_star)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        nm.notify(id, n)
    }
}

/** Receives Android's answer after we hand it an update to install. */
class InstallResultReceiver : BroadcastReceiver() {
    @Suppress("DEPRECATION")
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.getIntExtra(PackageInstaller.EXTRA_STATUS, -1)) {
            PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                // Android wants one tap from you to confirm the update.
                val confirm = intent.getParcelableExtra<Intent>(Intent.EXTRA_INTENT)
                if (confirm != null) {
                    confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    try {
                        context.startActivity(confirm)
                    } catch (e: Exception) {
                        Updater.notifyResult(context, "STAR update needs a tap", "Open STAR to finish installing the update.")
                    }
                }
            }
            PackageInstaller.STATUS_SUCCESS -> {
                // The new version replaces this one; nothing else to do.
            }
            else -> {
                val why = intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE) ?: "Unknown reason"
                Updater.notifyResult(context, "STAR update failed", why)
            }
        }
    }
}

/** Runs about once a day and tells you when a newer STAR has been published. */
class UpdateJobService : JobService() {
    override fun onStartJob(params: JobParameters): Boolean {
        val app = applicationContext
        Thread {
            try {
                val info = Updater.check(app)
                if (info != null) {
                    if (PublicPrefs.pendingUpdate(app) != info.version) Updater.notifyUpdate(app, info.version)
                    PublicPrefs.setPendingUpdate(app, info.version)
                } else {
                    PublicPrefs.setPendingUpdate(app, "")
                }
            } catch (e: Exception) {
                // offline or no release yet: try again tomorrow
            }
            jobFinished(params, false)
        }.start()
        return true
    }

    override fun onStopJob(params: JobParameters): Boolean = true

    companion object {
        private const val JOB_ID = 4101

        fun schedule(context: Context) {
            val scheduler = context.getSystemService(JobScheduler::class.java) ?: return
            if (PublicPrefs.updateRepo(context).isBlank()) {
                scheduler.cancel(JOB_ID)
                return
            }
            if (scheduler.getPendingJob(JOB_ID) != null) return
            val job = JobInfo.Builder(JOB_ID, ComponentName(context, UpdateJobService::class.java))
                .setPeriodic(24L * 60L * 60L * 1000L)
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setPersisted(true)
                .build()
            scheduler.schedule(job)
        }
    }
}
