package app.star.assistant

import android.Manifest
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.CancellationSignal
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.View
import android.view.WindowInsets
import android.view.WindowManager
import android.widget.FrameLayout

/** Everything that exists only while STAR is unlocked. It is wiped whenever STAR locks. */
object Session {
    var settings = StarSettings()
    var chats: MutableList<Chat> = ArrayList()
    var current: Chat? = null
    var models: List<Models.Info> = Models.builtIn

    fun load(context: Context) {
        settings = Store.loadSettings(context)
        chats = Store.loadChats(context)
        current = null
    }

    fun save(context: Context) {
        Store.saveChats(context, chats)
    }

    fun clear() {
        settings = StarSettings()
        chats = ArrayList()
        current = null
    }
}

private enum class Screen { LOCK, CHAT, HISTORY, SETTINGS }

class MainActivity : Activity() {
    private lateinit var container: FrameLayout
    private var chatScreen: ChatScreen? = null
    private var lockView: LockView? = null
    private var lockIsSetup = false
    private var screen = Screen.LOCK
    private var promptActive = false
    private var biometricCancel: CancellationSignal? = null
    private var stoppedAt = 0L
    private var lockPending = false
    private var screenOffReceiver: BroadcastReceiver? = null
    private val ui = Handler(Looper.getMainLooper())

    /** True while a question is being answered. */
    var busy = false

    // ------------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setDecorFitsSystemWindows(false)
        applySecureFlag()

        container = FrameLayout(this)
        container.setBackgroundColor(Theme.BG)
        container.setOnApplyWindowInsetsListener { v, insets ->
            val bars = insets.getInsets(
                WindowInsets.Type.systemBars() or WindowInsets.Type.ime() or WindowInsets.Type.displayCutout()
            )
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            WindowInsets.CONSUMED
        }
        setContentView(container)

        registerScreenOff()
        UpdateJobService.schedule(this)
        route()
    }

    override fun onStart() {
        super.onStart()
        if (Vault.isUnlocked && stoppedAt != 0L) {
            val graceMs = Session.settings.lockGraceSeconds * 1000L
            if (SystemClock.elapsedRealtime() - stoppedAt > graceMs) lockNow()
        }
    }

    override fun onResume() {
        super.onResume()
        if (!Vault.isUnlocked && screen != Screen.LOCK) route()
        maybeAutoPrompt()
    }

    override fun onStop() {
        super.onStop()
        stoppedAt = SystemClock.elapsedRealtime()
        if (Vault.isUnlocked && (isFinishing || Session.settings.lockGraceSeconds == 0)) lockNow()
    }

    override fun onDestroy() {
        super.onDestroy()
        val r = screenOffReceiver
        if (r != null) {
            try {
                unregisterReceiver(r)
            } catch (e: Exception) {
            }
        }
        if (isFinishing) {
            Vault.lock()
            Session.clear()
        }
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        if (screen == Screen.HISTORY || screen == Screen.SETTINGS) {
            showChat()
        } else {
            super.onBackPressed()
        }
    }

    private fun registerScreenOff() {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                if (Vault.isUnlocked) lockNow()
            }
        }
        screenOffReceiver = receiver
        val filter = IntentFilter(Intent.ACTION_SCREEN_OFF)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(receiver, filter)
        }
    }

    fun applySecureFlag() {
        if (PublicPrefs.blockScreenshots(this)) {
            window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
        }
    }

    fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            !PublicPrefs.askedNotifications(this) &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            PublicPrefs.setAskedNotifications(this)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7)
        }
    }

    // ------------------------------------------------------------------ routing

    /** Decides which screen to show based on whether STAR is set up and unlocked. */
    fun route() {
        if (!Vault.hasVault(this)) {
            chatScreen = null
            val lost = Vault.hadVaultFile(this)
            showLock(
                true,
                if (lost) "Your phone's fingerprints or faces changed, so STAR's vault key was destroyed to keep you safe. " +
                    "Setting STAR up again starts it fresh." else null
            )
        } else if (!Vault.isUnlocked) {
            chatScreen = null
            showLock(false, null)
        } else if (Session.settings.apiKey.isBlank()) {
            showSettings()
        } else {
            showChat()
        }
    }

    fun showChat() {
        screen = Screen.CHAT
        var cs = chatScreen
        if (cs == null) {
            cs = ChatScreen(this)
            chatScreen = cs
        } else if (!busy) {
            cs.renderAll()
        }
        swap(cs.root)
    }

    fun showHistory() {
        screen = Screen.HISTORY
        swap(HistoryScreen(this).root)
    }

    fun showSettings() {
        screen = Screen.SETTINGS
        swap(SettingsScreen(this).root)
    }

    private fun swap(view: View) {
        container.removeAllViews()
        container.addView(view, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    // ------------------------------------------------------------------ locking

    fun lockNow() {
        if (busy) {
            // An answer is still arriving. Stop it, hide everything right away, and lock for real as soon as the
            // partial answer has been saved (or after 8 seconds at the latest).
            if (!lockPending) {
                lockPending = true
                chatScreen?.cancelRequest()
                biometricCancel?.cancel()
                promptActive = false
                showLock(false, "Locking...")
                ui.postDelayed({
                    if (lockPending) {
                        busy = false
                        lockNow()
                    }
                }, 8000)
            }
            return
        }
        lockPending = false
        biometricCancel?.cancel()
        promptActive = false
        Vault.lock()
        Session.clear()
        chatScreen = null
        route()
    }

    fun onRequestFinished() {
        if (lockPending) lockNow()
    }

    private fun showLock(setup: Boolean, notice: String?) {
        screen = Screen.LOCK
        lockIsSetup = setup
        val view = LockView(this)
        lockView = view
        swap(view.root)
        when (Biometrics.availability(this)) {
            Biometrics.Availability.NO_HARDWARE -> view.show(
                "This phone has no strong biometric sensor (fingerprint, face or iris), so STAR can't protect itself here and won't run.",
                true
            )
            Biometrics.Availability.NONE_ENROLLED -> view.show(
                "Add a fingerprint or face in your phone's settings first. STAR uses them as its only key.",
                false,
                Action("Open phone settings") {
                    try {
                        startActivity(Biometrics.enrollIntent())
                    } catch (e: Exception) {
                        toast("Open your phone's Settings and add a fingerprint or face.")
                    }
                }
            )
            Biometrics.Availability.UNAVAILABLE -> view.show(
                "Biometric unlock isn't available right now. Try again in a moment.",
                true,
                Action("Try again") { route() }
            )
            Biometrics.Availability.READY -> {
                if (setup) {
                    view.show(
                        notice ?: "Welcome. STAR locks with your fingerprint or face and nothing else: no PIN, no password. " +
                            "Everything it stores is encrypted, and only a successful scan can open it.",
                        false,
                        Action("Set up with biometrics") { beginSetup() }
                    )
                } else {
                    view.show(notice ?: "Locked", false, Action("Unlock") { beginUnlock() })
                }
            }
        }
    }

    private fun maybeAutoPrompt() {
        if (screen == Screen.LOCK && !lockIsSetup && !promptActive && !lockPending &&
            Vault.hasVault(this) &&
            Biometrics.availability(this) == Biometrics.Availability.READY
        ) {
            beginUnlock()
        }
    }

    // ------------------------------------------------------------------ biometric flows

    private fun beginUnlock() {
        if (promptActive || lockPending) return
        val cipher = try {
            Vault.beginUnlock(this)
        } catch (e: VaultInvalidated) {
            Vault.wipe(this)
            showLock(
                true,
                "Your phone's fingerprints or faces changed, so STAR erased its vault to keep you safe. Set it up again."
            )
            return
        } catch (e: Exception) {
            lockView?.show(
                "Couldn't start the unlock: " + (e.message ?: "unknown error"),
                true,
                Action("Try again") { beginUnlock() }
            )
            return
        }
        promptActive = true
        biometricCancel = Biometrics.prompt(
            this, "Unlock STAR", "Use your fingerprint or face", cipher,
            { authorised ->
                promptActive = false
                try {
                    Vault.finishUnlock(this, authorised)
                    Session.load(this)
                    route()
                } catch (e: Exception) {
                    Vault.lock()
                    lockView?.show(
                        "Couldn't open the vault: " + (e.message ?: "unknown error"),
                        true,
                        Action("Try again") { beginUnlock() }
                    )
                }
            },
            { message, cancelled ->
                promptActive = false
                lockView?.show(if (cancelled) "Locked" else message, !cancelled, Action("Unlock") { beginUnlock() })
            }
        )
    }

    private fun beginSetup() {
        if (promptActive) return
        val cipher = try {
            Vault.beginSetup(this)
        } catch (e: Exception) {
            lockView?.show(
                "Couldn't create the secure key: " + (e.message ?: "unknown error"),
                true,
                Action("Try again") { beginSetup() }
            )
            return
        }
        promptActive = true
        biometricCancel = Biometrics.prompt(
            this, "Set up STAR", "Scan to create your private vault", cipher,
            { authorised ->
                promptActive = false
                try {
                    Vault.finishSetup(this, authorised)
                    Session.load(this)
                    route()
                } catch (e: Exception) {
                    Vault.wipe(this)
                    lockView?.show(
                        "Setup failed: " + (e.message ?: "unknown error"),
                        true,
                        Action("Try again") { beginSetup() }
                    )
                }
            },
            { message, cancelled ->
                promptActive = false
                Vault.wipe(this)
                lockView?.show(
                    if (cancelled) "Setup cancelled." else message,
                    !cancelled,
                    Action("Set up with biometrics") { beginSetup() }
                )
            }
        )
    }
}
