package app.star.assistant

import android.view.Gravity
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** The locked / first-run screen. It only shows a message and a few buttons; MainActivity runs the logic. */
class LockView(private val act: MainActivity) {
    val root = LinearLayout(act)
    private val message = act.label("", 16f, Theme.MUTED)
    private val buttons = LinearLayout(act)

    init {
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER
        root.setBackgroundColor(Theme.BG)
        root.setPadding(act.dp(32), act.dp(32), act.dp(32), act.dp(32))

        val star = act.label("★", 72f, Theme.ACCENT)
        star.gravity = Gravity.CENTER
        val title = act.label("STAR", 30f, Theme.TEXT, true)
        title.gravity = Gravity.CENTER
        message.gravity = Gravity.CENTER
        message.setPadding(0, act.dp(14), 0, act.dp(26))
        buttons.orientation = LinearLayout.VERTICAL

        root.addView(star, lp(WRAP, WRAP))
        root.addView(title, lp(WRAP, WRAP))
        root.addView(message, lp(MATCH, WRAP))
        root.addView(buttons, lp(MATCH, WRAP))
    }

    /** Shows [text] and one button per action (the first is the main one). */
    fun show(text: String, isError: Boolean, vararg actions: Action) {
        message.text = text
        message.setTextColor(if (isError) Theme.DANGER else Theme.MUTED)
        buttons.removeAllViews()
        for ((i, a) in actions.withIndex()) {
            val b = act.button(a.label, i == 0) { a.run() }
            val p = lp(MATCH, WRAP)
            p.topMargin = act.dp(10)
            buttons.addView(b, p)
        }
    }
}

/** List of saved chats. */
class HistoryScreen(private val act: MainActivity) {
    val root = LinearLayout(act)
    private val list = LinearLayout(act)

    init {
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Theme.BG)
        root.addView(act.topBar(Action("←") { act.showChat() }, "History"), lp(MATCH, WRAP))

        list.orientation = LinearLayout.VERTICAL
        list.setPadding(act.dp(12), act.dp(8), act.dp(12), act.dp(16))
        val scroll = ScrollView(act)
        scroll.addView(list, FrameLayout.LayoutParams(MATCH, WRAP))
        root.addView(scroll, lp(MATCH, 0, 1f))
        refresh()
    }

    private fun refresh() {
        list.removeAllViews()
        val chats = Session.chats.filter { it.messages.isNotEmpty() }.sortedByDescending { it.updated }
        if (chats.isEmpty()) {
            val empty = act.label("No saved chats yet.", 15f, Theme.MUTED)
            empty.setPadding(act.dp(4), act.dp(24), 0, 0)
            list.addView(empty, lp(MATCH, WRAP))
            return
        }
        val format = SimpleDateFormat("d MMM yyyy, HH:mm", Locale.getDefault())
        for (chat in chats) {
            val row = LinearLayout(act)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.background = roundRect(Theme.THEIRS, act.dp(14))
            row.setPadding(act.dp(14), act.dp(10), act.dp(6), act.dp(10))

            val column = LinearLayout(act)
            column.orientation = LinearLayout.VERTICAL
            column.addView(act.label(chat.title.ifEmpty { "Untitled" }, 16f, Theme.TEXT, true))
            val count = chat.messages.size
            column.addView(
                act.label(format.format(Date(chat.updated)) + "  ·  " + count + " messages", 12f, Theme.MUTED)
            )
            row.addView(column, lp(0, WRAP, 1f))

            val delete: TextView = act.label("✕", 18f, Theme.MUTED)
            delete.setPadding(act.dp(14), act.dp(10), act.dp(14), act.dp(10))
            delete.setOnClickListener {
                act.confirm("Delete this chat?", "It will be erased from this phone.", "Delete") {
                    Session.chats.remove(chat)
                    if (Session.current === chat) Session.current = null
                    try {
                        Session.save(act)
                    } catch (e: Exception) {
                        act.toast("Couldn't save: " + (e.message ?: "unknown error"))
                    }
                    refresh()
                }
            }
            row.addView(delete)

            row.setOnClickListener {
                if (act.busy) {
                    act.toast("Wait for STAR to finish first.")
                } else {
                    Session.current = chat
                    act.showChat()
                }
            }
            val params = lp(MATCH, WRAP)
            params.topMargin = act.dp(8)
            list.addView(row, params)
        }
    }
}
