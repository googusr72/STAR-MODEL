package app.star.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/** The Claude models STAR knows about out of the box. "Refresh models" in Settings adds any newer ones. */
object Models {
    const val DEFAULT = "claude-opus-5-5"

    class Info(val id: String, val label: String, val maxTokens: Int)

    val builtIn = listOf(
        Info("claude-opus-5-5", "Opus 5.5 - best all-round (recommended)", 128000),
        Info("claude-sonnet-5-5", "Sonnet 5.5 - fast, about half the cost", 128000),
        Info("claude-fable-5-1", "Fable 5.1 - strongest, slowest, priciest", 128000),
        Info("claude-haiku-5-5", "Haiku 5.5 - fastest and cheapest", 128000)
    )
}

class StarSettings {
    var apiKey = ""
    var model = Models.DEFAULT
    var effort = "high"          // low | medium | high | max
    var webSearch = true
    var instructions = ""
    var lockGraceSeconds = 0     // 0 = lock the moment STAR leaves the screen

    fun toJson(): JSONObject = JSONObject()
        .put("apiKey", apiKey)
        .put("model", model)
        .put("effort", effort)
        .put("webSearch", webSearch)
        .put("instructions", instructions)
        .put("lockGraceSeconds", lockGraceSeconds)

    companion object {
        fun fromJson(o: JSONObject): StarSettings {
            val s = StarSettings()
            s.apiKey = o.optString("apiKey", "")
            s.model = o.optString("model", Models.DEFAULT)
            s.effort = o.optString("effort", "high")
            s.webSearch = o.optBoolean("webSearch", true)
            s.instructions = o.optString("instructions", "")
            s.lockGraceSeconds = o.optInt("lockGraceSeconds", 0)
            return s
        }
    }
}

class Message(val role: String, val text: String, val time: Long, val error: Boolean = false)

class Chat(val id: String, var title: String, var updated: Long, val messages: MutableList<Message>) {
    companion object {
        fun create() = Chat(UUID.randomUUID().toString(), "", System.currentTimeMillis(), mutableListOf())
    }
}

/** Everything below is stored encrypted with the vault's master key. */
object Store {
    private const val SETTINGS_FILE = "settings.enc"
    private const val CHATS_FILE = "chats.enc"

    fun loadSettings(context: Context): StarSettings {
        val f = File(context.filesDir, SETTINGS_FILE)
        if (!f.exists()) return StarSettings()
        return try {
            StarSettings.fromJson(JSONObject(String(Vault.open(f.readBytes()), Charsets.UTF_8)))
        } catch (e: Exception) {
            StarSettings()
        }
    }

    fun saveSettings(context: Context, settings: StarSettings) {
        val bytes = settings.toJson().toString().toByteArray(Charsets.UTF_8)
        Vault.writeAtomic(File(context.filesDir, SETTINGS_FILE), Vault.seal(bytes))
    }

    fun loadChats(context: Context): MutableList<Chat> {
        val f = File(context.filesDir, CHATS_FILE)
        val out = ArrayList<Chat>()
        if (!f.exists()) return out
        try {
            val arr = JSONArray(String(Vault.open(f.readBytes()), Charsets.UTF_8))
            for (i in 0 until arr.length()) {
                val c = arr.getJSONObject(i)
                val msgs = ArrayList<Message>()
                val ma = c.optJSONArray("messages") ?: JSONArray()
                for (j in 0 until ma.length()) {
                    val m = ma.getJSONObject(j)
                    msgs.add(
                        Message(
                            m.optString("role", "user"),
                            m.optString("text", ""),
                            m.optLong("time", 0L),
                            m.optBoolean("error", false)
                        )
                    )
                }
                out.add(Chat(c.optString("id", UUID.randomUUID().toString()), c.optString("title", ""), c.optLong("updated", 0L), msgs))
            }
        } catch (e: Exception) {
            // unreadable file: start with an empty history rather than crash
        }
        out.sortByDescending { it.updated }
        return out
    }

    fun saveChats(context: Context, chats: List<Chat>) {
        val arr = JSONArray()
        for (c in chats) {
            if (c.messages.isEmpty()) continue
            val ma = JSONArray()
            for (m in c.messages) {
                ma.put(
                    JSONObject()
                        .put("role", m.role)
                        .put("text", m.text)
                        .put("time", m.time)
                        .put("error", m.error)
                )
            }
            arr.put(
                JSONObject()
                    .put("id", c.id)
                    .put("title", c.title)
                    .put("updated", c.updated)
                    .put("messages", ma)
            )
        }
        Vault.writeAtomic(File(context.filesDir, CHATS_FILE), Vault.seal(arr.toString().toByteArray(Charsets.UTF_8)))
    }
}

/** Non-secret switches that must be readable before unlocking (for example by the background update check). */
object PublicPrefs {
    private fun prefs(c: Context) = c.getSharedPreferences("star_public", Context.MODE_PRIVATE)

    fun updateRepo(c: Context): String = prefs(c).getString("updateRepo", "") ?: ""
    fun setUpdateRepo(c: Context, v: String) = prefs(c).edit().putString("updateRepo", v.trim()).apply()

    fun blockScreenshots(c: Context): Boolean = prefs(c).getBoolean("blockScreenshots", true)
    fun setBlockScreenshots(c: Context, v: Boolean) = prefs(c).edit().putBoolean("blockScreenshots", v).apply()

    fun pendingUpdate(c: Context): String = prefs(c).getString("pendingUpdate", "") ?: ""
    fun setPendingUpdate(c: Context, v: String) = prefs(c).edit().putString("pendingUpdate", v).apply()

    fun askedNotifications(c: Context): Boolean = prefs(c).getBoolean("askedNotifications", false)
    fun setAskedNotifications(c: Context) = prefs(c).edit().putBoolean("askedNotifications", true).apply()
}
