package app.star.assistant

import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/** STAR's night-sky colours. */
object Theme {
    val BG = Color.parseColor("#0B1020")
    val FIELD = Color.parseColor("#1B2342")
    val MINE = Color.parseColor("#2A3B94")
    val THEIRS = Color.parseColor("#171F3D")
    val TEXT = Color.parseColor("#E8EBFA")
    val MUTED = Color.parseColor("#97A0C9")
    val ACCENT = Color.parseColor("#FFC83D")
    val DANGER = Color.parseColor("#FF7B7B")
    val LINK = Color.parseColor("#8DB8FF")
    val ON_ACCENT = Color.parseColor("#1A1300")
}

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

/** A tappable item in a top bar. */
class Action(val label: String, val run: () -> Unit)

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

fun lp(w: Int, h: Int, weight: Float = 0f): LinearLayout.LayoutParams = LinearLayout.LayoutParams(w, h, weight)

fun roundRect(color: Int, radiusPx: Int): GradientDrawable {
    val d = GradientDrawable()
    d.setColor(color)
    d.cornerRadius = radiusPx.toFloat()
    return d
}

fun Context.label(text: String, sizeSp: Float = 15f, color: Int = Theme.TEXT, bold: Boolean = false): TextView {
    val t = TextView(this)
    t.text = text
    t.textSize = sizeSp
    t.setTextColor(color)
    if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
    return t
}

fun Context.section(text: String): TextView {
    val t = label(text.uppercase(), 12f, Theme.ACCENT, true)
    t.setPadding(0, dp(22), 0, dp(6))
    return t
}

fun Context.button(text: String, filled: Boolean = true, onClick: () -> Unit): TextView {
    val b = TextView(this)
    b.text = text
    b.textSize = 15f
    b.gravity = Gravity.CENTER
    b.setTypeface(b.typeface, Typeface.BOLD)
    b.setPadding(dp(18), dp(12), dp(18), dp(12))
    b.setTextColor(if (filled) Theme.ON_ACCENT else Theme.ACCENT)
    b.background = roundRect(if (filled) Theme.ACCENT else Theme.FIELD, dp(14))
    b.isClickable = true
    b.setOnClickListener { onClick() }
    return b
}

fun Context.field(
    hint: String,
    multiline: Boolean = false,
    secret: Boolean = false,
    noSuggestions: Boolean = true
): EditText {
    val e = EditText(this)
    e.hint = hint
    e.setHintTextColor(Theme.MUTED)
    e.setTextColor(Theme.TEXT)
    e.textSize = 15f
    e.setPadding(dp(14), dp(12), dp(14), dp(12))
    e.background = roundRect(Theme.FIELD, dp(12))
    var type = InputType.TYPE_CLASS_TEXT
    if (noSuggestions) type = type or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
    if (multiline) type = type or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
    if (secret) type = type or InputType.TYPE_TEXT_VARIATION_PASSWORD
    e.inputType = type
    // Ask the keyboard not to learn from (or sync) what is typed in STAR.
    e.imeOptions = e.imeOptions or EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING
    e.importantForAutofill = View.IMPORTANT_FOR_AUTOFILL_NO
    if (multiline) {
        e.minLines = 3
        e.gravity = Gravity.TOP or Gravity.START
    }
    return e
}

fun Context.toast(message: String) {
    Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}

fun Context.confirm(title: String, message: String, yes: String, onYes: () -> Unit) {
    AlertDialog.Builder(this)
        .setTitle(title)
        .setMessage(message)
        .setPositiveButton(yes) { _, _ -> onYes() }
        .setNegativeButton("Cancel", null)
        .show()
}

fun Context.topBar(left: Action?, title: String, vararg right: Action): LinearLayout {
    val bar = LinearLayout(this)
    bar.orientation = LinearLayout.HORIZONTAL
    bar.gravity = Gravity.CENTER_VERTICAL
    bar.setPadding(dp(6), dp(4), dp(6), dp(4))

    fun icon(a: Action): TextView {
        val t = label(a.label, 20f, Theme.TEXT)
        t.setPadding(dp(12), dp(10), dp(12), dp(10))
        t.setOnClickListener { a.run() }
        return t
    }

    if (left != null) bar.addView(icon(left))
    val titleView = label(title, 18f, Theme.TEXT, true)
    titleView.setPadding(dp(8), 0, dp(8), 0)
    bar.addView(titleView, lp(0, WRAP, 1f))
    for (a in right) bar.addView(icon(a))
    return bar
}
