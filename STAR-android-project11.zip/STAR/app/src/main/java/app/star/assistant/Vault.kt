package app.star.assistant

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.io.File
import java.io.IOException
import java.security.InvalidKeyException
import java.security.KeyStore
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/** Thrown when the hardware key is gone (for example because a new fingerprint/face was added to the phone). */
class VaultInvalidated : Exception("The phone's biometrics changed, so the vault key was destroyed.")

/**
 * STAR's vault.
 *
 * - One random 256-bit "master key" encrypts everything STAR stores (API key, settings, chats).
 * - The master key itself is stored only in wrapped form. The wrapping key lives inside the phone's secure hardware
 *   (Android Keystore, StrongBox when the phone has it) and can be used ONLY right after a fresh, successful
 *   STRONG biometric check (Class 3: fingerprint / face / iris, whichever your phone rates as strong).
 *   There is no PIN, pattern or password fallback.
 * - If a new biometric is enrolled on the phone, Android destroys the hardware key and STAR's vault becomes
 *   unreadable. That is deliberate: it stops someone who learns your phone PIN from adding their own face/finger.
 * - The unwrapped master key exists in memory only while STAR is unlocked, and is zeroed when STAR locks.
 */
object Vault {
    private const val ANDROID_KEYSTORE = "AndroidKeyStore"
    private const val KEY_ALIAS = "star_vault_wrap_key_v1"
    private const val WRAP_FILE = "vault.bin"
    private const val TRANSFORMATION = "AES/GCM/NoPadding"
    private const val TAG_BITS = 128
    private const val IV_BYTES = 12
    private const val FORMAT: Byte = 1

    @Volatile
    private var masterKey: ByteArray? = null

    val isUnlocked: Boolean get() = masterKey != null

    fun hasVault(context: Context): Boolean = hadVaultFile(context) && keyExists()

    /** True when an old vault file is still on disk (used to explain why STAR reset itself). */
    fun hadVaultFile(context: Context): Boolean = File(context.filesDir, WRAP_FILE).exists()

    // ---------------------------------------------------------------- hardware key

    private fun keyStore(): KeyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }

    private fun keyExists(): Boolean = try {
        keyStore().containsAlias(KEY_ALIAS)
    } catch (e: Exception) {
        false
    }

    private fun hardwareKey(): SecretKey =
        (keyStore().getKey(KEY_ALIAS, null) as? SecretKey) ?: throw VaultInvalidated()

    private fun spec(strongBox: Boolean): KeyGenParameterSpec {
        val b = KeyGenParameterSpec.Builder(
            KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .setUserAuthenticationRequired(true)
            // timeout 0 = a fresh biometric check is needed for EVERY use of the key
            .setUserAuthenticationParameters(0, KeyProperties.AUTH_BIOMETRIC_STRONG)
            .setInvalidatedByBiometricEnrollment(true)
            .setUnlockedDeviceRequired(true)
        if (strongBox) b.setIsStrongBoxBacked(true)
        return b.build()
    }

    private fun createKey() {
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
        try {
            generator.init(spec(true))
            generator.generateKey()
        } catch (e: Exception) {
            // No separate security chip on this phone (or it declined): use the normal secure hardware instead.
            try {
                keyStore().deleteEntry(KEY_ALIAS)
            } catch (ignored: Exception) {
            }
            generator.init(spec(false))
            generator.generateKey()
        }
    }

    // ---------------------------------------------------------------- first-time setup

    /** Creates a fresh hardware key. Returns a cipher that the biometric prompt must authorise. */
    fun beginSetup(context: Context): Cipher {
        wipe(context)
        createKey()
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, hardwareKey())
        return cipher
    }

    /** Call with the cipher the biometric prompt handed back after a successful scan. */
    fun finishSetup(context: Context, authorised: Cipher) {
        val fresh = ByteArray(32)
        SecureRandom().nextBytes(fresh)
        val wrapped = authorised.doFinal(fresh)
        val iv = authorised.iv
        val blob = byteArrayOf(FORMAT, iv.size.toByte()) + iv + wrapped
        writeAtomic(File(context.filesDir, WRAP_FILE), blob)
        masterKey = fresh
    }

    // ---------------------------------------------------------------- unlock / lock

    /** Returns a cipher that the biometric prompt must authorise. Throws [VaultInvalidated] if the key is gone. */
    fun beginUnlock(context: Context): Cipher {
        val blob = File(context.filesDir, WRAP_FILE).readBytes()
        if (blob.size < 3 || blob[0] != FORMAT) throw VaultInvalidated()
        val ivLen = blob[1].toInt()
        val iv = blob.copyOfRange(2, 2 + ivLen)
        val cipher = Cipher.getInstance(TRANSFORMATION)
        try {
            cipher.init(Cipher.DECRYPT_MODE, hardwareKey(), GCMParameterSpec(TAG_BITS, iv))
        } catch (e: InvalidKeyException) {
            // includes KeyPermanentlyInvalidatedException (new biometric enrolled)
            throw VaultInvalidated()
        }
        return cipher
    }

    fun finishUnlock(context: Context, authorised: Cipher) {
        val blob = File(context.filesDir, WRAP_FILE).readBytes()
        val start = 2 + blob[1].toInt()
        masterKey = authorised.doFinal(blob, start, blob.size - start)
    }

    fun lock() {
        masterKey?.fill(0)
        masterKey = null
    }

    /** Erases the hardware key and every file STAR has stored. */
    fun wipe(context: Context) {
        lock()
        try {
            keyStore().deleteEntry(KEY_ALIAS)
        } catch (e: Exception) {
        }
        context.filesDir.listFiles()?.forEach { it.delete() }
    }

    // ---------------------------------------------------------------- encrypt / decrypt STAR's own data

    /** AES-256-GCM with a fresh random nonce every time. Layout: [format][12-byte nonce][ciphertext+tag]. */
    fun seal(plain: ByteArray): ByteArray {
        val key = masterKey ?: throw IllegalStateException("STAR is locked")
        val iv = ByteArray(IV_BYTES)
        SecureRandom().nextBytes(iv)
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(TAG_BITS, iv))
        return byteArrayOf(FORMAT) + iv + cipher.doFinal(plain)
    }

    fun open(blob: ByteArray): ByteArray {
        val key = masterKey ?: throw IllegalStateException("STAR is locked")
        if (blob.size < 1 + IV_BYTES + 16 || blob[0] != FORMAT) throw IOException("Unreadable data")
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(TAG_BITS, blob, 1, IV_BYTES))
        return cipher.doFinal(blob, 1 + IV_BYTES, blob.size - 1 - IV_BYTES)
    }

    fun writeAtomic(target: File, bytes: ByteArray) {
        val tmp = File(target.parentFile, target.name + ".tmp")
        tmp.writeBytes(bytes)
        if (!tmp.renameTo(target)) {
            target.delete()
            if (!tmp.renameTo(target)) throw IOException("Could not save " + target.name)
        }
    }
}
