package app.star.assistant

import android.os.Handler
import android.os.Looper
import android.text.method.LinkMovementMethod
import android.view.Gravity
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** The main conversation screen. One instance lives while STAR is unlocked. */
class ChatScreen(private val act: MainActivity) {
    val root = LinearLayout(act)
    private val list = LinearLayout(act)
    private val scroll = ScrollView(act)
    private val status = TextView(act)
    private val input: EditText = act.field("Ask STAR anything", multiline = true, noSuggestions = false)
    private val sendButton = TextView(act)
    private val ui = Handler(Looper.getMainLooper())

    private var handle: CallHandle? = null
    private var liveView: TextView? = null
    private val liveBuf = StringBuilder()
    private var renderQueued = false

    init {
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Theme.BG)

        root.addView(
            act.topBar(
                Action("☰") { act.showHistory() },
                "★ STAR",
                Action("✚") { newChat() },
                Action("⚙") { act.showSettings() },
                Action("🔒") { act.lockNow() }
            ),
            lp(MATCH, WRAP)
        )

        list.orientation = LinearLayout.VERTICAL
        list.setPadding(act.dp(10), act.dp(8), act.dp(10), act.dp(8))
        scroll.addView(list, FrameLayout.LayoutParams(MATCH, WRAP))
        scroll.isFillViewport = true
        root.addView(scroll, lp(MATCH, 0, 1f))

        status.textSize = 13f
        status.setTextColor(Theme.MUTED)
        status.setPadding(act.dp(18), act.dp(2), act.dp(18), act.dp(2))
        root.addView(status, lp(MATCH, WRAP))

        val row = LinearLayout(act)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.BOTTOM
        row.setPadding(act.dp(10), act.dp(4), act.dp(10), act.dp(10))

        input.minLines = 1
        input.maxLines = 6
        row.addView(input, lp(0, WRAP, 1f))

        sendButton.text = "➤"
        sendButton.textSize = 20f
        sendButton.gravity = Gravity.CENTER
        sendButton.setTextColor(Theme.ON_ACCENT)
        sendButton.background = roundRect(Theme.ACCENT, act.dp(23))
        sendButton.setOnClickListener { onSendPressed() }
        val sendParams = lp(act.dp(46), act.dp(46))
        sendParams.leftMargin = act.dp(8)
        row.addView(sendButton, sendParams)
        root.addView(row, lp(MATCH, WRAP))

        renderAll()
    }

    // ------------------------------------------------------------------ drawing

    fun renderAll() {
        list.removeAllViews()
        val chat = Session.current
        if (chat == null || chat.messages.isEmpty()) {
            val hello = act.label("★\nAsk STAR anything", 22f, Theme.MUTED)
            hello.gravity = Gravity.CENTER
            hello.setPadding(0, act.dp(90), 0, 0)
            list.addView(hello, lp(MATCH, WRAP))
            return
        }
        for (m in chat.messages) addBubble(m)
        scrollToBottom(true)
    }

    private fun makeBubble(mine: Boolean, error: Boolean): TextView {
        val t = TextView(act)
        t.textSize = 16f
        t.setLineSpacing(0f, 1.1f)
        t.setTextColor(if (error) Theme.DANGER else Theme.TEXT)
        t.setLinkTextColor(Theme.LINK)
        t.setPadding(act.dp(14), act.dp(10), act.dp(14), act.dp(10))
        t.background = roundRect(if (mine) Theme.MINE else Theme.THEIRS, act.dp(18))
        t.setTextIsSelectable(true)
        t.movementMethod = LinkMovementMethod.getInstance()
        return t
    }

    private fun bubbleParams(mine: Boolean): LinearLayout.LayoutParams {
        val p = lp(WRAP, WRAP)
        p.gravity = if (mine) Gravity.END else Gravity.START
        p.topMargin = act.dp(6)
        p.bottomMargin = act.dp(2)
        if (mine) p.leftMargin = act.dp(48) else p.rightMargin = act.dp(24)
        return p
    }

    private fun addBubble(m: Message) {
        val mine = m.role == "user"
        val t = makeBubble(mine, m.error)
        t.text = if (mine || m.error) m.text else Markdown.render(m.text)
        list.addView(t, bubbleParams(mine))
    }

    private fun scrollToBottom(force: Boolean) {
        scroll.post {
            val child = scroll.getChildAt(0)
            if (child != null) {
                val distance = child.height - (scroll.height + scroll.scrollY)
                if (force || distance < act.dp(180)) {
                    scroll.scrollTo(0, maxOf(0, child.height - scroll.height))
                }
            }
        }
    }

    private fun scheduleRender() {
        if (renderQueued) return
        renderQueued = true
        ui.postDelayed({
            renderQueued = false
            val v = liveView
            if (v != null) {
                v.text = Markdown.render(liveBuf.toString())
                scrollToBottom(false)
            }
        }, 70)
    }

    // ------------------------------------------------------------------ actions

    private fun newChat() {
        if (act.busy) {
            act.toast("Wait for STAR to finish, or tap the stop button.")
            return
        }
        Session.current = null
        status.text = ""
        renderAll()
    }

    private fun onSendPressed() {
        if (act.busy) {
            handle?.cancel()
        } else {
            send()
        }
    }

    /** Stops the answer that is currently streaming (used when STAR locks). */
    fun cancelRequest() {
        handle?.cancel()
    }

    private fun persist() {
        if (!Vault.isUnlocked) return
        try {
            Session.save(act)
        } catch (e: Exception) {
            act.toast("Couldn't save the chat: " + (e.message ?: "unknown error"))
        }
    }

    private fun send() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        val settings = Session.settings
        if (settings.apiKey.isBlank()) {
            act.toast("Add your Anthropic API key in Settings first.")
            act.showSettings()
            return
        }

        var chat = Session.current
        if (chat == null) {
            chat = Chat.create()
            Session.chats.add(0, chat)
            Session.current = chat
        }
        val now = System.currentTimeMillis()
        val userMsg = Message("user", text, now)
        chat.messages.add(userMsg)
        if (chat.title.isEmpty()) chat.title = text.replace('\n', ' ').take(48)
        chat.updated = now
        persist()
        input.setText("")

        if (chat.messages.size == 1) list.removeAllViews()
        addBubble(userMsg)
        val live = makeBubble(false, false)
        live.text = ""
        liveView = live
        liveBuf.setLength(0)
        list.addView(live, bubbleParams(false))
        scrollToBottom(true)

        act.busy = true
        sendButton.text = "■"
        status.text = "Thinking..."

        val callHandle = CallHandle()
        handle = callHandle
        val history = ArrayList(chat.messages)
        val system = Prompts.system(settings)
        val cap = Session.models.firstOrNull { it.id == settings.model }?.maxTokens ?: 0
        val target = chat

        Thread {
            var answer: Answer? = null
            var failure: Throwable? = null
            try {
                answer = ClaudeClient.stream(settings, history, system, cap, object : StreamListener {
                    override fun onText(delta: String) {
                        ui.post {
                            liveBuf.append(delta)
                            status.text = ""
                            scheduleRender()
                        }
                    }

                    override fun onStatus(status: String) {
                        ui.post { this@ChatScreen.status.text = status }
                    }
                }, callHandle)
            } catch (e: Throwable) {
                failure = e
            }
            ui.post { finish(target, answer, failure) }
        }.start()
    }

    private fun finish(chat: Chat, answer: Answer?, failure: Throwable?) {
        act.busy = false
        sendButton.text = "➤"
        status.text = ""
        val now = System.currentTimeMillis()

        if (answer != null) {
            var body = answer.text
            if (answer.stopped) body = if (body.isEmpty()) "(stopped)" else "$body\n\n(stopped)"
            val note = answer.note
            if (note != null) body = if (body.isEmpty()) note else "$body\n\n$note"
            if (body.isNotBlank()) chat.messages.add(Message("assistant", body, now))
        } else if (failure != null) {
            val partial = liveBuf.toString().trim()
            if (partial.isNotEmpty()) chat.messages.add(Message("assistant", partial, now))
            chat.messages.add(Message("assistant", ClaudeClient.describe(failure), now, true))
        }
        chat.updated = now
        persist()
        liveView = null
        handle = null
        if (Session.current === chat) renderAll()
        act.onRequestFinished()
    }
}
