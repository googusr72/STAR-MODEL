package app.star.assistant

import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.TreeMap

class ApiException(val status: Int, val kind: String, message: String) : Exception(message)

/** Lets the screen stop a request that is running on a background thread. */
class CallHandle {
    @Volatile
    var cancelled = false

    @Volatile
    private var connection: HttpURLConnection? = null

    fun attach(c: HttpURLConnection?) {
        connection = c
        if (cancelled) cancel()
    }

    fun cancel() {
        cancelled = true
        val c = connection ?: return
        // Closing a socket must not happen on the main thread.
        Thread {
            try {
                c.disconnect()
            } catch (e: Exception) {
            }
        }.start()
    }
}

interface StreamListener {
    /** Called on the background thread with each new piece of the answer. */
    fun onText(delta: String)

    /** Short progress label such as "Thinking..." or "Searching: ...". */
    fun onStatus(status: String)
}

class Answer(val text: String, val stopped: Boolean, val note: String?)

/**
 * Talks to Anthropic's Messages API over plain HTTPS (no libraries).
 * Streams the answer, lets Claude use the server-side web search tool, and rebuilds the
 * assistant turn so a long search ("pause_turn") can be continued.
 */
object ClaudeClient {
    private const val BASE = "https://api.anthropic.com/v1"
    private const val API_VERSION = "2023-06-01"
    private const val SEARCH_TOOL = "web_search_20250305"
    private val effortModels = Regex("^claude-(opus|sonnet|fable|mythos)-5.*")

    private class Options(var webSearch: Boolean, var effort: Boolean)

    private class Turn {
        val blocks = TreeMap<Int, JSONObject>()
        val inputBuffers = HashMap<Int, StringBuilder>()
        var stopReason: String? = null

        fun content(): JSONArray {
            val a = JSONArray()
            for (b in blocks.values) a.put(b)
            return a
        }
    }

    // ------------------------------------------------------------------ chat

    /** Blocks until the answer is complete (or cancelled). Call from a background thread. */
    fun stream(
        settings: StarSettings,
        history: List<Message>,
        system: String,
        modelCap: Int,
        listener: StreamListener,
        handle: CallHandle
    ): Answer {
        val messages = buildMessages(history)
        val text = StringBuilder()
        val sources = LinkedHashMap<String, String>()
        val options = Options(settings.webSearch, effortModels.matches(settings.model))
        var note: String? = null
        var rounds = 0

        while (true) {
            val turn = Turn()
            runOnce(settings, options, messages, system, modelCap, listener, handle, turn, text)
            collectSources(turn, sources)
            if (handle.cancelled) return Answer(finish(text, sources), true, null)

            val stop = turn.stopReason
            if (stop == "pause_turn" && rounds < 4) {
                // The search was paused by the server: send its partial turn back unchanged so it can carry on.
                messages.put(JSONObject().put("role", "assistant").put("content", turn.content()))
                rounds++
                listener.onStatus("Still working...")
                continue
            }
            if (stop == "pause_turn") note = "I stopped after a very long search. Say \"continue\" and I'll pick up."
            if (stop == "max_tokens") note = "The answer hit its length limit and was cut off. Say \"continue\" for the rest."
            if (stop == "refusal") note = "The model declined this request."
            break
        }
        return Answer(finish(text, sources), false, note)
    }

    private fun runOnce(
        settings: StarSettings,
        options: Options,
        messages: JSONArray,
        system: String,
        modelCap: Int,
        listener: StreamListener,
        handle: CallHandle,
        turn: Turn,
        text: StringBuilder
    ) {
        var attempt = 0
        while (true) {
            attempt++
            val body = JSONObject()
                .put("model", settings.model)
                .put("max_tokens", maxTokens(settings, modelCap))
                .put("stream", true)
                .put("system", system)
                .put("messages", messages)
            if (options.effort) body.put("output_config", JSONObject().put("effort", settings.effort))
            if (options.webSearch) {
                body.put(
                    "tools",
                    JSONArray().put(
                        JSONObject().put("type", SEARCH_TOOL).put("name", "web_search").put("max_uses", 5)
                    )
                )
            }

            val conn = open("/messages", settings.apiKey, "POST")
            handle.attach(conn)
            try {
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json")
                conn.setRequestProperty("Accept", "text/event-stream")
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

                val code = conn.responseCode
                if (code !in 200..299) {
                    val err = readError(conn, code)
                    val msg = err.message ?: ""
                    if (attempt < 4 && !handle.cancelled) {
                        if (code == 400 && options.effort &&
                            (msg.contains("effort", true) || msg.contains("output_config", true))
                        ) {
                            options.effort = false
                            continue
                        }
                        if (code == 400 && options.webSearch &&
                            (msg.contains("web search", true) || msg.contains("web_search", true))
                        ) {
                            options.webSearch = false
                            listener.onStatus("Web search isn't available on this API account, answering without it.")
                            continue
                        }
                        if (code == 529 || code == 503 || code == 500) {
                            Thread.sleep(2500)
                            continue
                        }
                    }
                    throw err
                }
                readStream(conn, turn, listener, text)
                return
            } catch (e: IOException) {
                if (handle.cancelled) return
                throw e
            } finally {
                conn.disconnect()
            }
        }
    }

    private fun readStream(conn: HttpURLConnection, turn: Turn, listener: StreamListener, text: StringBuilder) {
        BufferedReader(InputStreamReader(conn.inputStream, Charsets.UTF_8)).use { reader ->
            val data = StringBuilder()
            while (true) {
                val line = reader.readLine() ?: break
                if (line.isEmpty()) {
                    if (data.isNotEmpty()) {
                        handleEvent(data.toString(), turn, listener, text)
                        data.setLength(0)
                    }
                } else if (line.startsWith("data:")) {
                    if (data.isNotEmpty()) data.append('\n')
                    data.append(line.substring(5).trimStart())
                }
            }
            if (data.isNotEmpty()) handleEvent(data.toString(), turn, listener, text)
        }
    }

    private fun handleEvent(json: String, turn: Turn, listener: StreamListener, text: StringBuilder) {
        val e = try {
            JSONObject(json)
        } catch (ex: Exception) {
            return
        }
        when (e.optString("type")) {
            "content_block_start" -> {
                val index = e.optInt("index", -1)
                val start = e.optJSONObject("content_block") ?: return
                val block = JSONObject(start.toString())
                turn.blocks[index] = block
                when (block.optString("type")) {
                    "text" -> {
                        if (text.isNotEmpty() && !text.endsWith("\n\n")) {
                            text.append("\n\n")
                            listener.onText("\n\n")
                        }
                    }
                    "thinking" -> listener.onStatus("Thinking...")
                    "server_tool_use", "tool_use" -> {
                        turn.inputBuffers[index] = StringBuilder()
                        listener.onStatus("Searching the web...")
                    }
                    "web_search_tool_result" -> listener.onStatus("Reading results...")
                }
            }

            "content_block_delta" -> {
                val index = e.optInt("index", -1)
                val block = turn.blocks[index] ?: return
                val d = e.optJSONObject("delta") ?: return
                when (d.optString("type")) {
                    "text_delta" -> {
                        val t = d.optString("text", "")
                        block.put("text", block.optString("text", "") + t)
                        text.append(t)
                        listener.onText(t)
                    }
                    "thinking_delta" ->
                        block.put("thinking", block.optString("thinking", "") + d.optString("thinking", ""))
                    "signature_delta" -> block.put("signature", d.optString("signature", ""))
                    "input_json_delta" -> turn.inputBuffers[index]?.append(d.optString("partial_json", ""))
                    "citations_delta" -> {
                        val c = d.optJSONObject("citation")
                        if (c != null) {
                            var arr = block.optJSONArray("citations")
                            if (arr == null) {
                                arr = JSONArray()
                                block.put("citations", arr)
                            }
                            arr.put(c)
                        }
                    }
                }
            }

            "content_block_stop" -> {
                val index = e.optInt("index", -1)
                val buf = turn.inputBuffers.remove(index)
                val block = turn.blocks[index]
                if (buf != null && block != null) {
                    val parsed = try {
                        if (buf.isBlank()) JSONObject() else JSONObject(buf.toString())
                    } catch (ex: Exception) {
                        JSONObject()
                    }
                    block.put("input", parsed)
                    val q = parsed.optString("query", "")
                    if (block.optString("type") == "server_tool_use" && q.isNotEmpty()) {
                        listener.onStatus("Searching: $q")
                    }
                }
            }

            "message_delta" -> {
                val d = e.optJSONObject("delta")
                if (d != null && !d.isNull("stop_reason")) turn.stopReason = d.optString("stop_reason")
            }

            "error" -> {
                val err = e.optJSONObject("error")
                val kind = err?.optString("type", "error") ?: "error"
                val msg = err?.optString("message", "The stream failed") ?: "The stream failed"
                throw ApiException(if (kind == "overloaded_error") 529 else 500, kind, msg)
            }
        }
    }

    // ------------------------------------------------------------------ helpers

    /** Alternating user/assistant turns only; failed turns are left out; must start with the user. */
    private fun buildMessages(history: List<Message>): JSONArray {
        val turns = ArrayList<Pair<String, String>>()
        for (m in history) {
            if (m.error || m.text.isBlank()) continue
            if (turns.isNotEmpty() && turns[turns.size - 1].first == m.role) {
                val prev = turns.removeAt(turns.size - 1)
                turns.add(Pair(m.role, prev.second + "\n\n" + m.text))
            } else {
                turns.add(Pair(m.role, m.text))
            }
        }
        while (turns.isNotEmpty() && turns[0].first != "user") turns.removeAt(0)
        val arr = JSONArray()
        for (t in turns) arr.put(JSONObject().put("role", t.first).put("content", t.second))
        return arr
    }

    private fun collectSources(turn: Turn, sources: MutableMap<String, String>) {
        for (b in turn.blocks.values) {
            if (b.optString("type") != "text") continue
            val cites = b.optJSONArray("citations") ?: continue
            for (i in 0 until cites.length()) {
                val c = cites.optJSONObject(i) ?: continue
                val url = c.optString("url", "")
                if (url.startsWith("http") && !sources.containsKey(url)) {
                    sources[url] = c.optString("title", url)
                }
            }
        }
    }

    private fun finish(text: StringBuilder, sources: Map<String, String>): String {
        val out = StringBuilder(text.toString().trim())
        if (sources.isNotEmpty()) {
            out.append("\n\n**Sources**\n")
            var n = 0
            for ((url, title) in sources) {
                if (n >= 8) break
                n++
                val t = title.replace('[', '(').replace(']', ')').replace('\n', ' ').trim().ifEmpty { url }
                val u = url.replace(")", "%29").replace(" ", "%20")
                out.append("- [").append(t).append("](").append(u).append(")\n")
            }
        }
        return out.toString().trim()
    }

    private fun maxTokens(s: StarSettings, modelCap: Int): Int {
        val want = if (s.effort == "max") 64000 else 32000
        return if (modelCap > 0) minOf(want, modelCap) else want
    }

    private fun open(path: String, key: String, method: String): HttpURLConnection {
        val c = URL(BASE + path).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 20_000
        c.readTimeout = 180_000
        c.useCaches = false
        c.setRequestProperty("x-api-key", key)
        c.setRequestProperty("anthropic-version", API_VERSION)
        c.setRequestProperty("Accept-Encoding", "identity") // keeps the live stream from being buffered
        return c
    }

    private fun readError(c: HttpURLConnection, code: Int): ApiException {
        val raw = try {
            (c.errorStream ?: c.inputStream).bufferedReader(Charsets.UTF_8).use { it.readText() }
        } catch (e: Exception) {
            ""
        }
        var kind = "http_$code"
        var msg = "The server answered HTTP $code"
        try {
            val err = JSONObject(raw).optJSONObject("error")
            if (err != null) {
                kind = err.optString("type", kind)
                msg = err.optString("message", msg)
            }
        } catch (e: Exception) {
        }
        return ApiException(code, kind, msg)
    }

    /** Asks Anthropic which models exist right now, so new ones show up without an app update. */
    fun listModels(key: String): List<Models.Info> {
        val out = ArrayList<Models.Info>()
        var after = ""
        for (page in 0 until 5) {
            val path = "/models?limit=100" + (if (after.isNotEmpty()) "&after_id=$after" else "")
            val c = open(path, key, "GET")
            try {
                val code = c.responseCode
                if (code !in 200..299) throw readError(c, code)
                val json = JSONObject(c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() })
                val data = json.optJSONArray("data") ?: break
                for (i in 0 until data.length()) {
                    val m = data.optJSONObject(i) ?: continue
                    val id = m.optString("id", "")
                    if (!id.startsWith("claude-")) continue
                    if (m.optString("lifecycle", "active") != "active") continue
                    out.add(Models.Info(id, m.optString("display_name", id), m.optInt("max_tokens", 0)))
                }
                if (!json.optBoolean("has_more", false)) break
                after = json.optString("last_id", "")
                if (after.isEmpty()) break
            } finally {
                c.disconnect()
            }
        }
        return out
    }

    /** Plain-language explanation of what went wrong. */
    fun describe(e: Throwable): String = when {
        e is ApiException && e.status == 401 -> "Anthropic rejected your API key. Open Settings and check it."
        e is ApiException && e.status == 403 -> "Your API key isn't allowed to do that. " + (e.message ?: "")
        e is ApiException && e.status == 429 -> "Too many requests right now (rate limit). Wait a little and try again."
        e is ApiException && e.status >= 500 -> "Anthropic's servers are busy. Try again in a moment."
        e is ApiException -> e.message ?: "The request failed."
        e is UnknownHostException || e is SocketTimeoutException -> "Couldn't reach Anthropic. Check your internet connection."
        e is IOException -> "Connection problem: " + (e.message ?: "unknown")
        else -> "Something went wrong: " + (e.message ?: e.javaClass.simpleName)
    }
}

object Prompts {
    fun system(settings: StarSettings): String {
        val now = SimpleDateFormat("EEEE d MMMM yyyy, HH:mm", Locale.ENGLISH).format(Date())
        val sb = StringBuilder()
        sb.append("You are STAR, a personal AI assistant that lives on the user's Android phone. ")
        sb.append("You are built on Anthropic's Claude models; if asked what you run on, say so plainly.\n\n")
        sb.append("How to behave:\n")
        sb.append("- Accuracy comes first. If you are unsure, or the answer may have changed recently, say so or search. ")
        sb.append("Never invent facts, numbers, quotes or sources.\n")
        sb.append("- Use web search for anything current (news, prices, rules, schedules, \"latest\", \"today\") and rely on what you find.\n")
        sb.append("- Be direct and useful: lead with the answer, then give the reasoning that lets the user check it. Match length to the question.\n")
        sb.append("- Format with Markdown: short paragraphs, lists only when they help, fenced code blocks for code. ")
        sb.append("Tables render poorly on a phone, so prefer lists.\n")
        sb.append("- You can only reply in this chat. Don't claim to have done anything on the phone or anywhere else.\n\n")
        sb.append("Current date and time: ").append(now).append(" (").append(TimeZone.getDefault().id).append(").\n")
        val extra = settings.instructions.trim()
        if (extra.isNotEmpty()) {
            sb.append("\nThe user's own standing instructions for you (follow them):\n").append(extra).append('\n')
        }
        return sb.toString()
    }
}
