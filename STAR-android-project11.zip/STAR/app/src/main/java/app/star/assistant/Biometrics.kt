package app.star.assistant

import android.app.Activity
import android.content.Intent
import android.hardware.biometrics.BiometricManager
import android.hardware.biometrics.BiometricPrompt
import android.os.CancellationSignal
import android.provider.Settings
import javax.crypto.Cipher

/**
 * Thin wrapper around Android's built-in biometric prompt.
 *
 * STAR asks for BIOMETRIC_STRONG only (no PIN / pattern fallback) and ties the scan to a cipher, so the scan
 * is verified by the phone's secure hardware rather than just by STAR's own code.
 *
 * Android does NOT let an app say "fingerprint AND face". The phone decides which of its enrolled strong
 * biometrics to accept. STAR therefore guarantees "a strong biometric, every time, no fallback".
 */
object Biometrics {
    enum class Availability { READY, NONE_ENROLLED, NO_HARDWARE, UNAVAILABLE }

    // Stable values from Android's BiometricConstants.
    private const val ERR_CANCELED = 5
    private const val ERR_USER_CANCELED = 10
    private const val ERR_NEGATIVE_BUTTON = 13

    fun availability(activity: Activity): Availability {
        val manager = activity.getSystemService(BiometricManager::class.java)
            ?: return Availability.NO_HARDWARE
        return when (manager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG)) {
            BiometricManager.BIOMETRIC_SUCCESS -> Availability.READY
            BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED -> Availability.NONE_ENROLLED
            BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE -> Availability.NO_HARDWARE
            else -> Availability.UNAVAILABLE
        }
    }

    /** Opens the phone's own screen for adding a fingerprint / face. */
    fun enrollIntent(): Intent =
        Intent(Settings.ACTION_BIOMETRIC_ENROLL).putExtra(
            Settings.EXTRA_BIOMETRIC_AUTHENTICATORS_ALLOWED,
            BiometricManager.Authenticators.BIOMETRIC_STRONG
        )

    /**
     * Shows the system biometric prompt. Exactly one of [onSuccess] / [onFailure] is called, once.
     * [onFailure] gets (message, wasCancelledByUser).
     */
    fun prompt(
        activity: Activity,
        title: String,
        subtitle: String,
        cipher: Cipher,
        onSuccess: (Cipher) -> Unit,
        onFailure: (String, Boolean) -> Unit
    ): CancellationSignal {
        val executor = activity.mainExecutor
        val cancel = CancellationSignal()
        var done = false

        fun succeed(c: Cipher) {
            if (done) return
            done = true
            onSuccess(c)
        }

        fun fail(message: String, cancelled: Boolean) {
            if (done) return
            done = true
            onFailure(message, cancelled)
        }

        val prompt = BiometricPrompt.Builder(activity)
            .setTitle(title)
            .setSubtitle(subtitle)
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)
            .setConfirmationRequired(true)
            .setNegativeButton("Cancel", executor) { _, _ -> fail("Cancelled", true) }
            .build()

        prompt.authenticate(
            BiometricPrompt.CryptoObject(cipher),
            cancel,
            executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    val authorised = result.cryptoObject?.cipher
                    if (authorised == null) fail("The scan did not unlock the key. Try again.", false)
                    else succeed(authorised)
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    val cancelled = errorCode == ERR_CANCELED ||
                        errorCode == ERR_USER_CANCELED ||
                        errorCode == ERR_NEGATIVE_BUTTON
                    fail(errString.toString(), cancelled)
                }
            }
        )
        return cancel
    }
}
