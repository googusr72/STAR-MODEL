package app.star.assistant

import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.ArrayAdapter
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView

/** Everything you can change about STAR. */
class SettingsScreen(private val act: MainActivity) {
    val root = LinearLayout(act)

    private val apiKey = act.field("Paste your key (starts with sk-ant-)", secret = true)
    private val modelSpinner = Spinner(act)
    private val effortSpinner = Spinner(act)
    private val searchSwitch = Switch(act)
    private val instructions = act.field(
        "Anything STAR should always know or do. Example: Call me Sam. Keep answers short.",
        multiline = true,
        noSuggestions = false
    )
    private val graceSpinner = Spinner(act)
    private val screenshotSwitch = Switch(act)
    private val repoField = act.field("owner/repository (optional)")
    private val updateStatus = act.label("", 13f, Theme.MUTED)
    private val installButton: TextView
    private val ui = Handler(Looper.getMainLooper())

    private var modelList: List<Models.Info> = Session.models
    private var pending: UpdateInfo? = null

    private val efforts = listOf(
        "low" to "Quick (cheapest)",
        "medium" to "Balanced",
        "high" to "Thorough (recommended)",
        "max" to "Maximum (slowest, costliest)"
    )
    private val graces = listOf(
        0 to "Immediately when I leave STAR",
        30 to "After 30 seconds away",
        120 to "After 2 minutes away"
    )

    init {
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Theme.BG)
        root.addView(act.topBar(Action("←") { act.showChat() }, "Settings"), lp(MATCH, WRAP))

        val body = LinearLayout(act)
        body.orientation = LinearLayout.VERTICAL
        body.setPadding(act.dp(16), act.dp(0), act.dp(16), act.dp(32))

        // --- API key
        body.addView(act.section("Anthropic API key"))
        body.addView(note("STAR thinks using Claude through your own Anthropic account. Create a key at console.anthropic.com and add a few dollars of credit. The key is stored encrypted and opens only after your biometric scan."))
        body.addView(apiKey, lp(MATCH, WRAP))

        // --- model
        body.addView(act.section("Model"))
        modelSpinner.adapter = adapterOf(modelList.map { it.label })
        body.addView(modelSpinner, lp(MATCH, WRAP))
        val refresh = act.button("Refresh model list", false) { refreshModels() }
        val refreshParams = lp(MATCH, WRAP)
        refreshParams.topMargin = act.dp(8)
        body.addView(refresh, refreshParams)

        // --- depth
        body.addView(act.section("Thinking depth"))
        effortSpinner.adapter = adapterOf(efforts.map { it.second })
        body.addView(effortSpinner, lp(MATCH, WRAP))
        body.addView(note("Deeper thinking is more accurate on hard questions but slower and costs more."))

        // --- web search
        body.addView(act.section("Web search"))
        searchSwitch.text = "Let STAR search the web for current facts (small extra charge per search)"
        searchSwitch.setTextColor(Theme.TEXT)
        body.addView(searchSwitch, lp(MATCH, WRAP))

        // --- instructions
        body.addView(act.section("Your instructions to STAR"))
        body.addView(note("STAR follows these in every chat. Change them any time to change how STAR behaves."))
        body.addView(instructions, lp(MATCH, WRAP))

        // --- security
        body.addView(act.section("Privacy and security"))
        graceSpinner.adapter = adapterOf(graces.map { it.second })
        body.addView(note("Lock STAR:"))
        body.addView(graceSpinner, lp(MATCH, WRAP))
        screenshotSwitch.text = "Block screenshots and hide STAR in the app switcher"
        screenshotSwitch.setTextColor(Theme.TEXT)
        val shotParams = lp(MATCH, WRAP)
        shotParams.topMargin = act.dp(10)
        body.addView(screenshotSwitch, shotParams)

        // --- updates
        body.addView(act.section("Updates"))
        body.addView(note("STAR can check a GitHub repository you control for newer releases and install them after verifying them. Leave empty to turn this off."))
        body.addView(repoField, lp(MATCH, WRAP))
        val checkButton = act.button("Check for updates now", false) { checkNow() }
        val checkParams = lp(MATCH, WRAP)
        checkParams.topMargin = act.dp(8)
        body.addView(checkButton, checkParams)
        installButton = act.button("Download and install the update") { installNow() }
        installButton.visibility = View.GONE
        val installParams = lp(MATCH, WRAP)
        installParams.topMargin = act.dp(8)
        body.addView(installButton, installParams)
        updateStatus.setPadding(0, act.dp(8), 0, 0)
        body.addView(updateStatus, lp(MATCH, WRAP))

        // --- save
        val saveButton = act.button("Save") { save() }
        val saveParams = lp(MATCH, WRAP)
        saveParams.topMargin = act.dp(26)
        body.addView(saveButton, saveParams)

        // --- how it protects you
        body.addView(act.section("How STAR protects you"))
        body.addView(
            note(
                "• Everything STAR stores is encrypted with a key that your phone's secure hardware releases only right after a fingerprint or face scan. There is no PIN or password fallback.\n\n" +
                    "• Adding a new fingerprint or face to the phone destroys that key, and STAR resets itself.\n\n" +
                    "• STAR locks when you leave it and hides itself from screenshots.\n\n" +
                    "• Android does not let an app demand a fingerprint AND a face together. STAR demands a strong biometric every time and accepts whichever strong one your phone has.\n\n" +
                    "• Your messages are sent to Anthropic over encrypted connections so Claude can answer them.\n\n" +
                    "• No app is unhackable. If someone controls your unlocked phone, or you install a fake copy of STAR, these protections cannot help."
            )
        )

        // --- danger
        body.addView(act.section("Danger zone"))
        val eraseButton = act.button("Erase everything on this phone", false) { erase() }
        eraseButton.setTextColor(Theme.DANGER)
        body.addView(eraseButton, lp(MATCH, WRAP))

        val scroll = ScrollView(act)
        scroll.addView(body, FrameLayout.LayoutParams(MATCH, WRAP))
        root.addView(scroll, lp(MATCH, 0, 1f))

        load()
    }

    // ------------------------------------------------------------------ helpers

    private fun note(text: String): TextView {
        val t = act.label(text, 13f, Theme.MUTED)
        t.setPadding(0, 0, 0, act.dp(8))
        return t
    }

    private fun adapterOf(items: List<String>): ArrayAdapter<String> {
        val a = ArrayAdapter(act, android.R.layout.simple_spinner_item, items)
        a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        return a
    }

    private fun load() {
        val s = Session.settings
        apiKey.setText(s.apiKey)
        modelSpinner.setSelection(maxOf(0, modelList.indexOfFirst { it.id == s.model }))
        effortSpinner.setSelection(maxOf(0, efforts.indexOfFirst { it.first == s.effort }))
        searchSwitch.isChecked = s.webSearch
        instructions.setText(s.instructions)
        graceSpinner.setSelection(maxOf(0, graces.indexOfFirst { it.first == s.lockGraceSeconds }))
        screenshotSwitch.isChecked = PublicPrefs.blockScreenshots(act)
        repoField.setText(PublicPrefs.updateRepo(act))
        val waiting = PublicPrefs.pendingUpdate(act)
        updateStatus.text = if (waiting.isNotEmpty()) "Version $waiting is available. Checking..." else
            "Installed version: " + Updater.installedVersion(act)
        if (waiting.isNotEmpty() && PublicPrefs.updateRepo(act).isNotBlank()) checkNow()
    }

    // ------------------------------------------------------------------ actions

    private fun save() {
        val s = Session.settings
        val key = apiKey.text.toString().trim()
        s.apiKey = key
        s.model = modelList.getOrNull(modelSpinner.selectedItemPosition)?.id ?: s.model
        s.effort = efforts[effortSpinner.selectedItemPosition].first
        s.webSearch = searchSwitch.isChecked
        s.instructions = instructions.text.toString().trim()
        s.lockGraceSeconds = graces[graceSpinner.selectedItemPosition].first
        try {
            Store.saveSettings(act, s)
        } catch (e: Exception) {
            act.toast("Couldn't save: " + (e.message ?: "unknown error"))
            return
        }
        PublicPrefs.setBlockScreenshots(act, screenshotSwitch.isChecked)
        PublicPrefs.setUpdateRepo(act, repoField.text.toString())
        act.applySecureFlag()
        UpdateJobService.schedule(act)
        if (repoField.text.toString().isNotBlank()) act.askNotificationPermission()
        if (key.isNotEmpty() && !key.startsWith("sk-ant-")) {
            act.toast("Saved, but that doesn't look like an Anthropic key (they start with sk-ant-).")
        } else {
            act.toast("Saved.")
        }
        act.showChat()
    }

    private fun refreshModels() {
        val typed = apiKey.text.toString().trim()
        val key = if (typed.isNotEmpty()) typed else Session.settings.apiKey
        if (key.isEmpty()) {
            act.toast("Enter your API key first.")
            return
        }
        Thread {
            try {
                val found = ClaudeClient.listModels(key)
                ui.post { mergeModels(found) }
            } catch (e: Exception) {
                ui.post { act.toast(ClaudeClient.describe(e)) }
            }
        }.start()
    }

    private fun mergeModels(found: List<Models.Info>) {
        val selectedId = modelList.getOrNull(modelSpinner.selectedItemPosition)?.id ?: Session.settings.model
        val merged = ArrayList<Models.Info>(Models.builtIn)
        for (f in found) {
            if (merged.none { it.id == f.id }) merged.add(Models.Info(f.id, f.label + " (" + f.id + ")", f.maxTokens))
        }
        Session.models = merged
        modelList = merged
        modelSpinner.adapter = adapterOf(merged.map { it.label })
        modelSpinner.setSelection(maxOf(0, merged.indexOfFirst { it.id == selectedId }))
        act.toast("Model list updated.")
    }

    private fun checkNow() {
        PublicPrefs.setUpdateRepo(act, repoField.text.toString())
        updateStatus.text = "Checking..."
        installButton.visibility = View.GONE
        val app = act.applicationContext
        Thread {
            try {
                val info = Updater.check(app)
                ui.post {
                    pending = info
                    if (info == null) {
                        updateStatus.text = "You're up to date (version " + Updater.installedVersion(app) + ")."
                    } else {
                        updateStatus.text = "Version " + info.version + " is available."
                        installButton.visibility = View.VISIBLE
                    }
                }
            } catch (e: Exception) {
                ui.post { updateStatus.text = e.message ?: "Couldn't check for updates." }
            }
        }.start()
    }

    private fun installNow() {
        val info = pending ?: return
        if (!Updater.canInstall(act)) {
            act.toast("Allow STAR to install updates on the next screen, then come back, unlock STAR and check for updates again.")
            act.startActivity(Updater.allowInstallIntent(act))
            return
        }
        val app = act.applicationContext
        updateStatus.text = "Downloading..."
        Thread {
            try {
                val file = Updater.download(app, info) { pct -> ui.post { updateStatus.text = "Downloading... $pct%" } }
                ui.post { updateStatus.text = "Verified. Android will ask you to confirm the update." }
                Updater.install(app, file)
            } catch (e: Exception) {
                ui.post { updateStatus.text = e.message ?: "The update failed." }
            }
        }.start()
    }

    private fun erase() {
        act.confirm(
            "Erase everything?",
            "This deletes your API key, settings and all chats from this phone and resets STAR. It can't be undone.",
            "Erase"
        ) {
            Vault.wipe(act)
            Session.clear()
            act.route()
        }
    }
}
