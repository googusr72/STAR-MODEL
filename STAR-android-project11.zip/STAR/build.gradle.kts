// Top-level build file. STAR has no third-party libraries on purpose:
// fewer parts = fewer things that can break or be attacked.
plugins {
    id("com.android.application") version "8.7.3" apply false
    id("org.jetbrains.kotlin.android") version "2.0.21" apply false
}
